﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Models
{
    public class Computers : Department
    {
        public int NumberofStudents { get; set; }
        public int NumberofLabsConducted { get; set; }

    }
}