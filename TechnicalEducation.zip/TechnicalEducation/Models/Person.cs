﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class Person 
    {
        ///<summary>
        /// Gets or sets PersonId.
        ///</summary>
        public int PersonId { get; set; }

        ///<summary>
        /// Gets or sets Name.
        ///</summary>
        [Required(AllowEmptyStrings = true, ErrorMessage = "Text Box value Required")]
        [StringLength(10)]
        public string Name { get; set; }

        ///<summary>
        /// Gets or sets Gender.
        ///</summary>
        public string Gender { get; set; }

        ///<summary>
        /// Gets or sets City.
        ///</summary>
        public string City { get; set; }

        //public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        //{
        //    if(Person==null)
        //    {
        //        yield return new ValidationResult("Model2 is required", new { "Person"   });
        //    }
        //}
    }
}
