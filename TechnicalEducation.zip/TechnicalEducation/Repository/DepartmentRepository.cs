﻿using Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;

namespace Repository
{
    public class DepartmentRepository : IDepartment
    {
        public Computers GetDepartmentById(int deptId)
        {
            Computers compDept = null;
            try
            {
                Department dept = new Department();
                compDept = new Computers();
                dept = GetDepartments().Where(p => p.DeptId == deptId).FirstOrDefault();
                compDept.NumberofLabsConducted = 20;
                compDept.NumberofStudents = 30;
                compDept.DeptId = dept.DeptId;
                compDept.DeptName = dept.DeptName;
                compDept.HODName = dept.HODName;
            }
            catch (Exception ex)
            {
                throw;
            }
            return compDept;
        }

        public IEnumerable<Department> GetDepartments()
        {
            List<Department> studentList = null;
            try
            {
                studentList = new List<Department>()
                {
                    new Department {DeptId = 100, DeptName="Computers", HODName="Mohan"},
                    new Department {DeptId = 101, DeptName="Physics", HODName="Chandini"},
                    new Department {DeptId = 100, DeptName="Chemistry", HODName="Madhu"},
                };
            }
            catch (Exception ex)
            {
                throw;
            }
            return studentList;
        }

    }
}



