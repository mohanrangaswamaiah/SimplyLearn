﻿using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TechnicalEducation.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ViewResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }


        public ContentResult MadhuName()
        {
            return Content("Hi Madhu");
        }
        public string ChandniName()
        {
            return "Hi Chandni";
        }

        [HttpGet]
        public ActionResult Person()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Person(Person person)
        {
            if(ModelState.IsValid)
            { 
            int personId = person.PersonId;
            string name = person.Name;
            string gender = person.Gender;
            string city = person.City;
            }
            return View("~/Views/Home/PersonDisplay.cshtml", person);
        }
    }
}