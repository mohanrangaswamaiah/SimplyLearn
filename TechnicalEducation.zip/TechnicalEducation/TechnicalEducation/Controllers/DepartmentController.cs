﻿using Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TechnicalEducation.Controllers
{
    public class DepartmentController : Controller
    {
        // GET: Department

        DepartmentRepository deptRepo = new DepartmentRepository();
        public ActionResult Computers()
        {
            var dept = deptRepo.GetDepartmentById(100);
            return View("~/Views/Computers/Computers.cshtml",dept);
        }

        public ActionResult Departments()
        {
            var deptList=deptRepo.GetDepartments();
            return View(deptList);
        }

        public ActionResult AllDepartment()
        {
            return View(deptRepo.GetDepartments());
        }
    }
}