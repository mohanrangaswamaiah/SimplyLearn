﻿using System.Web.UI;

namespace WebApp.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}